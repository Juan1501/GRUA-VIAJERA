package com.lolazoguillermozapata_gmail.com.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
EditText edtTextOut;
ImageButton btnEnviar, btnArriba, btnDerecha,btnIzquierda,btnAbajo,btnAvanzar, btnRetroceder, btnStop;
TextView tvtMensaje;
Button btnDesconectar;
    //-------------------------------------------
    Handler bluetoothIn;
    final int handlerState = 0;
    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private StringBuilder DataStringIN = new StringBuilder();
    private ConnectedThread MyConexionBT;
    // Identificador unico de servicio - SPP UUID
    private static final UUID BTMODULEUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    // String para la direccion MAC
    private static String address = null;
    //-------------------------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bluetoothIn = new Handler() {
            public void handleMessage(android.os.Message msg) {
                if (msg.what == handlerState) {
                    //Interacción con los datos de ingreso
                    char MyCaracter = (char) msg.obj;

                    if (MyCaracter == 'a') {
                        tvtMensaje.setText("Arriba");
                    }

                    if (MyCaracter == 'd') {
                        tvtMensaje.setText("Derecha");
                    }

                    if (MyCaracter == 'i') {
                        tvtMensaje.setText("Izquierda");
                    }

                    if (MyCaracter == 'b') {
                        tvtMensaje.setText("Abajo");
                    }

                    if (MyCaracter == 'v') {
                        tvtMensaje.setText("Avanzar");
                    }
                    if (MyCaracter=='r') {
                        tvtMensaje.setText("Retroceder");
                    }
                     if(MyCaracter== 's') {
                         tvtMensaje.setText("Detener");
                    }
                }
            }
        };


        edtTextOut=findViewById(R.id.edtTextOut);
        btnEnviar= findViewById(R.id.btnEnviar);
        btnArriba=findViewById(R.id.btnArriba);
        btnDerecha= findViewById(R.id.btnDerecha);
        btnIzquierda= findViewById(R.id.btnIzquierda);
        btnAbajo= findViewById(R.id.btnAbajo);
        btnAvanzar= findViewById(R.id.btnAvanzar);
        btnRetroceder= findViewById(R.id.btnRetroceder);
        btnStop=findViewById(R.id.btnStop);
        tvtMensaje= findViewById(R.id.tvtMensaje);
        btnDesconectar=findViewById (R.id.btnDesconectar);



            }
        });
        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //--------
        String GetDat= edtTextOut.getText().toString();

        //tvtMensaje.setText(GetDat);
        MyConexionBT.write(GetDat);

            }
        });

        btnArriba.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        MyConexionBT.write(input"a");
            }
        });
        btnDerecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               MyConexionBT.write(input"d")
            }
        });
        btnIzquierda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyconexionBT.write(input "i")

            }
        });
        btnAbajo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyconexionBT.write(input "b")

            }
        });
        btnAvanzar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyconexionBT.write(input "v")

            }
        });
        btnRetroceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyconexionBT.write(input "r")

            }
        });
        btnStop.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                MyconexionBT.write(input "s")

        }
        });
        btnDesconectar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
        if (btSocket != null)
        {
        try {btSocket.close();}
        catch (IOException e)
        {Toast.makeText(getBaseContext(), "Error", Toast.LENGTH_SHORT).show();;}
        }

        finish();
        }
        });
private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
        }
        return device.createRfcommSocketToServiceRecord(BTMODULEUUID);
        //creates secure outgoing connecetion with BT device using UUID
        }

@Override
public void onResume() {
        super.onResume();

        Intent intent = getIntent();
        address = intent.getStringExtra(DispositivosVinculados.EXTRA_DEVICE_ADDRESS);
        //Setea la direccion MAC
        BluetoothDevice device = btAdapter.getRemoteDevice(address);

        try {
        btSocket = createBluetoothSocket(device);
        } catch (IOException e) {
        Toast.makeText(getBaseContext(), "La creacción del Socket fallo", Toast.LENGTH_LONG).show();
        }
        // Establece la conexión con el socket Bluetooth.
        try {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
        // TODO: Consider calling
        //    ActivityCompat#requestPermissions
        // here to request the missing permissions, and then overriding
        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
        //                                          int[] grantResults)
        // to handle the case where the user grants the permission. See the documentation
        // for ActivityCompat#requestPermissions for more details.
        btSocket.connect();
        //Toast.makeText(getBaseContext(), "CONEXION EXITOSA", Toast.LENGTH_SHORT).show();

        //return;
        }

        //btSocket.connect();
        } catch (IOException e) {
        try {
        btSocket.close();
        } catch (IOException e2) {
        }
        }
        MyConexionBT = new ConnectedThread(btSocket);
        MyConexionBT.start();
        }

@Override
public void onPause() {
        super.onPause();
        try { // Cuando se sale de la aplicación esta parte permite que no se deje abierto el socket
        btSocket.close();
        } catch (IOException e2) {
        }
        }

//Comprueba que el dispositivo Bluetooth
//está disponible y solicita que se active si está desactivado
private void VerificarEstadoBT() {

        if (btAdapter == null) {
        Toast.makeText(getBaseContext(), "El dispositivo no soporta bluetooth", Toast.LENGTH_LONG).show();
        } else {
        if (btAdapter.isEnabled()) {
        } else {
        Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
        // TODO: Consider calling
        //    ActivityCompat#requestPermissions
        // here to request the missing permissions, and then overriding
        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
        //                                          int[] grantResults)
        // to handle the case where the user grants the permission. See the documentation
        // for ActivityCompat#requestPermissions for more details.
        startActivityForResult(enableBtIntent, 1);
        //return;
        }

        }
        }
        }

//Crea la clase que permite crear el evento de conexion
private class ConnectedThread extends Thread
{
    private final InputStream mmInStream;
    private final OutputStream mmOutStream;

    public ConnectedThread(BluetoothSocket socket)
    {
        InputStream tmpIn = null;
        OutputStream tmpOut = null;
        try
        {
            tmpIn = socket.getInputStream();
            tmpOut = socket.getOutputStream();
        } catch (IOException e) { }
        mmInStream = tmpIn;
        mmOutStream = tmpOut;
    }

    public void run()
    {
        byte[] byte_in = new byte[1];
        // Se mantiene en modo escucha para determinar el ingreso de datos
        while (true) {
            try {
                mmInStream.read(byte_in);
                char ch = (char) byte_in[0];
                bluetoothIn.obtainMessage(handlerState, ch).sendToTarget();
            } catch (IOException e) {
                break;
            }
        }
    }

    //Envio de trama
    public void write(String input)
    {
        try {
            mmOutStream.write(input.getBytes());
        }
        catch (IOException e)
        {
            //si no es posible enviar datos se cierra la conexión
            Toast.makeText(getBaseContext(), "La Conexión fallo", Toast.LENGTH_LONG).show();
            finish();
        }
    }
}
        }



